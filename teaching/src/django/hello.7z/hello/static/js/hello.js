console.log("hello");

const element = document.getElementById("link");

// This handler will be executed only once when the cursor
// moves over the unordered list
element.addEventListener(
  "mouseover",
  (event) => {
    // highlight the mouseenter target
    event.target.style.backgroundColor = "lightblue";

    // reset the color after a short delay
    setTimeout(() => {
      event.target.style.backgroundColor = "";
    }, 2000);
  },
  false,
);

